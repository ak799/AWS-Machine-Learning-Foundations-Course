from setuptools import setup

setup(name='ak7_distributions',
      version='0.1',
      description='A test case of Gaussian distributions',
      packages=['distributions'],
      author='Aashis Kumar',
      author_email= 'aashismanav@gmail.com',
      zip_safe=False)